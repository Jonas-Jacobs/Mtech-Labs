//
//  ViewController.swift
//  Light
//
//  Created by Jonas Jacobs on 8/25/21.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var lightON = true

    fileprivate func UpdateUI() {
        if lightON {
            view.backgroundColor = lightON ? .white : .black
        }
    }
    @IBAction func ButtonTapped(_ sender: Any)
    { lightON.toggle()
        UpdateUI()
    }
}

